import csv
import datetime
import os
import RPi.GPIO as GPIO
import time
import utils
import json
class App:
    def __init__(self):
        
        self.led = utils.LED()

        
        self.BUTTON_PIN = 18
        # Set up GPIO mode and initial state
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        # Define a variable to track the last button state
        self.last_button_state = GPIO.input(self.BUTTON_PIN)
        self.is_online = False  # Initialize online state to False
        script_directory = os.path.dirname(os.path.abspath(__file__))
        self.log_folder = os.path.join(script_directory, "data/logs")
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
        self.csv_file_path = os.path.join(self.log_folder, 'logs.csv')
        # Add an event detection for the button pin (both rising and falling edges)
        GPIO.add_event_detect(self.BUTTON_PIN, GPIO.BOTH, callback=self.button_callback, bouncetime=200)

    def button_callback(self, channel):
        current_button_state = GPIO.input(channel)
        if current_button_state == GPIO.HIGH and self.last_button_state == GPIO.LOW:
            print("Button is pressed")
            self.is_online = True  # Set online state to True when button is pressed
            self.log_event('ONLINE')
        elif current_button_state == GPIO.LOW and self.last_button_state == GPIO.HIGH:
            print("Button is released")
            self.is_online = False  # Set online state to False when button is released
            self.log_event('OFFLINE')
            self.save_idle_state(False)
            self.led.turn_off_all()
        self.last_button_state = current_button_state

    def log_event(self, message):
        current_time = datetime.datetime.now()
        date = current_time.strftime('%Y-%m-%d')
        time = current_time.strftime('%H:%M:%S')
        with open(self.csv_file_path, mode='a', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow([message, date, time])


    def save_idle_state(self, val):
        with open('config/idle_state.json', 'w') as state_file:
            json.dump({'idle_started': val}, state_file)
if __name__ == "__main__":   
    app = App()
    try:
        # Your code can continue running here without blocking
        while True:
            pass  # Keep the script running without using a traditional loop
    except KeyboardInterrupt:
        pass
    finally:
        # Clean up GPIO pins
        GPIO.cleanup()
