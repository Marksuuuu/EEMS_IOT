import RPi.GPIO as GPIO
import time

# Define GPIO pin numbers for each LED


class LED:
    def __init__(self):

        self.GREEN_PIN = 27
        self.ORANGE_PIN = 22
        self.RED_PIN = 17
        
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.GREEN_PIN, GPIO.OUT)
        GPIO.setup(self.ORANGE_PIN, GPIO.OUT)
        GPIO.setup(self.RED_PIN, GPIO.OUT)
        

    # Turn on the GREEN LED
    def turn_on_green(self):
        GPIO.output(self.GREEN_PIN, GPIO.LOW)
        GPIO.output(self.ORANGE_PIN, GPIO.HIGH)
        GPIO.output(self.RED_PIN, GPIO.HIGH)

    # Turn on the ORANGE LED
    def turn_on_orange(self):
        GPIO.output(self.ORANGE_PIN, GPIO.LOW)
        GPIO.output(self.GREEN_PIN, GPIO.HIGH)
        GPIO.output(self.RED_PIN, GPIO.HIGH)

    # Turn on the RED LED
    def turn_on_red(self):
        GPIO.output(self.RED_PIN, GPIO.LOW)
        GPIO.output(self.GREEN_PIN, GPIO.HIGH)
        GPIO.output(self.ORANGE_PIN, GPIO.HIGH)

    # Turn off all LEDs
    def turn_off_all(self):
        GPIO.output(self.GREEN_PIN, GPIO.LOW)
        GPIO.output(self.ORANGE_PIN, GPIO.LOW)
        GPIO.output(self.RED_PIN, GPIO.LOW)

    # Cleanup GPIO settings on program exit
    def cleanup_gpio(self):
        GPIO.cleanup()
        
    def test(self):
        try:
            self.initialize_gpio()

            # Test the LEDs
            self.turn_on_green()
            time.sleep(2)  # Keep GREEN LED on for 2 seconds

            self.turn_on_orange()
            time.sleep(2)  # Keep ORANGE LED on for 2 seconds

            self.turn_on_red()
            time.sleep(2)  # Keep RED LED on for 2 seconds

            self.turn_off_all()

        except KeyboardInterrupt:
            pass
        finally:
            self.cleanup_gpio()

if __name__ == "__main__":
    LED()
