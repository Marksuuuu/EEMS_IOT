import json

CONFIG_FILE_PATH = "config/raspi_config.json"

def read_config():
	try:
		with open(CONFIG_FILE_PATH) as config_file:
			config = json.load(config_file)
	except FileNotFoundError:
		config = {}
	return config
	
	
def write_config(config):
	with open(CONFIG_FILE_PATH, "w") as config_file:
		json.dump(config, config_file)
