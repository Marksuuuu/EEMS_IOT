import csv
import datetime
import os
import RPi.GPIO as GPIO
import time
# from utils import LED
import json

class App:
    def __init__(self):
        
        self.led = LED()
        # self.turn_on_green()
        
        self.BUTTON_PIN = 18
        # Set up GPIO mode and initial state
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        # Define a variable to track the last button state
        self.last_button_state = GPIO.input(self.BUTTON_PIN)
        self.is_online = False  # Initialize online state to False
        script_directory = os.path.dirname(os.path.abspath(__file__))
        self.log_folder = os.path.join(script_directory, "../data/logs")
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
        self.csv_file_path = os.path.join(self.log_folder, 'logs.csv')
        # Add an event detection for the button pin (both rising and falling edges)
        GPIO.add_event_detect(self.BUTTON_PIN, GPIO.BOTH, callback=self.button_callback, bouncetime=200)

    def button_callback(self, channel):
        current_button_state = GPIO.input(channel)
        if current_button_state == GPIO.HIGH and self.last_button_state == GPIO.LOW:
            print("Button is pressed")
            self.is_online = True  # Set online state to True when button is pressed
            self.log_event('ONLINE')
        elif current_button_state == GPIO.LOW and self.last_button_state == GPIO.HIGH:
            print("Button is released")
            self.is_online = False  # Set online state to False when button is released
            self.log_event('OFFLINE')
            self.check_idle_condition()
            # self.led.turn_off_all()
        self.last_button_state = current_button_state

    def log_event(self, message):
        current_time = datetime.datetime.now()
        date = current_time.strftime('%Y-%m-%d')
        time = current_time.strftime('%H:%M:%S')
        with open(self.csv_file_path, mode='a', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow([message, date, time])

    def get_last_csv_value(self):
        try:
            with open('data/logs/idle.csv', mode="r", newline="") as csv_file:
                csv_reader = csv.reader(csv_file)
                rows = list(csv_reader)
                if rows:
                    last_row = rows[-1]
                    return last_row
                else:
                    return None
        except FileNotFoundError:
            print("CSV file not found.")
            return None
        
        # Define a function to execute the idle check
    def check_idle_condition(self):
        last_row = self.get_last_csv_value()
        if last_row and last_row[0] == "IDLE_START":
            last_time = datetime.datetime.strptime(last_row[2], "%H:%M:%S")
            self.idle_log_event("IDLE_STOP")

        # Schedule the check_idle_condition function to run after 10 seconds
        self.root.after(10000, self.check_idle_condition)

    def idle_log_event(self, msg):
        current_time = datetime.datetime.now()
        date = current_time.strftime("%Y-%m-%d")
        time = current_time.strftime("%H:%M:%S")

        with open('data/logs/idle.csv', mode="a", newline="") as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow([msg, date, time])

    def load_idle_state(self):
        try:
            with open('config/idle_state.json', 'r') as state_file:
                state = json.load(state_file)
                print(state)
                return state.get('idle_started', False)
        except FileNotFoundError:
            return False

    def save_idle_state(self):
        with open('config/idle_state.json', 'w') as state_file:
            json.dump({'idle_started': self.idle_started}, state_file)           

if __name__ == "__main__":   
    app = App()
    try:
        # Your code can continue running here without blocking
        while True:
            pass  # Keep the script running without using a traditional loop
    except KeyboardInterrupt:
        pass
    finally:
        # Clean up GPIO pins
        GPIO.cleanup()
